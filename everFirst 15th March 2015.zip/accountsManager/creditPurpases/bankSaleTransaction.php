
<div class="section fix" id="workOrderInvoice" style="margin:0px auto;" >
	<table>
	<tr><th>Invoice</th></tr>
	<tr><td><input onkeydown="if (event.keyCode == 13) bankSaleTransaction();" id="invoice" type="text"/></td>	<td >
	<input onclick="bankSaleTransaction();" type="button" value="submit"/>
	</td></tr>
	</table>
	
	</div>

<div id="commonContent"></div>
<div id="massage"></div>