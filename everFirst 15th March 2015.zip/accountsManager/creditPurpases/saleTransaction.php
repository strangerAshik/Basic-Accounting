
<div class="section fix" id="workOrderInvoice"  >
	<table>
	
	<tr><th>Invoice</th><td><input onkeydown="if (event.keyCode == 13) cashSaleTransaction();" id="invoice" type="text"/></td><td >
	<input onclick="cashSaleTransaction();" type="button" value="submit"/>
	</td></tr>
	</table>
	</div>
<div id="commonContent"></div>
<div id="massage"></div>
